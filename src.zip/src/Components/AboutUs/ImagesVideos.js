import React from 'react';
import { Grid, Typography } from '@material-ui/core';
import Image from '../../Assets/Dummy.png';
import { makeStyles } from '@material-ui/core';
import { Button } from '@material-ui/core';
const useStyles = makeStyles({
    size : {
        width : "100%",
        height : "25vh"
    },
    background : {
        backgroundColor : "#efefef",
        maxWidth : "900px",
        width : "100%",
        margin : "auto",
        marginTop : "20px",
    },
    alignCenter : {
        textAlign : "center",
        fontWeight : "bold",
    },
    buttonAlignment : {
        display : "flex",
        justifyContent : "center",
        marginTop : "20px",
    },
    textWhite : {
        color : "white",
    }
})
const ImagesVideos = () =>
{
    const classes = useStyles();
    return(
    <>
    <Grid container spacing = {1} className = {classes.background}>
        <Grid xs = {12}>
            <Typography align = "center" variant = "h5" className = {classes.alignCenter}>
                Images/Videos Gallery
            </Typography>
        </Grid>
        <Grid item xs = {12} sm = {6}>
            <img src = {Image} className = {classes.size}/>
        </Grid>
        <Grid item xs = {12} sm = {6}>
        <img src = {Image} className = {classes.size} />
        </Grid>
        <Grid item xs = {12} sm = {6}>
        <img src = {Image} className = {classes.size} />
        </Grid>
        <Grid item xs = {12} sm = {6}>
        <img src = {Image} className = {classes.size} />
        </Grid>
        <Grid item xs = {12} sm = {6}>
        <img src = {Image} className = {classes.size} />
        </Grid>
        <Grid item xs = {12} sm = {6}>
        <img src = {Image} className = {classes.size} />
        </Grid>
    </Grid>
        <Grid container className = {classes.buttonAlignment}>
       <Button color = "primary" variant = "contained" className = {classes.textWhite}>See More</Button>
       </Grid>
    </>
    )
}
export default ImagesVideos;