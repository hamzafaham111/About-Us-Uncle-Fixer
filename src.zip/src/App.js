import React from 'react';
import HomePage from './Components/AboutUs/HomePage';

const App = () =>
{
    return(
    <>
        <HomePage/>
    </>)
}
export default App;